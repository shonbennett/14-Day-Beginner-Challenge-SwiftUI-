//
//  ButtonPracticeApp.swift
//  ButtonPractice
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

@main
struct ButtonPracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
