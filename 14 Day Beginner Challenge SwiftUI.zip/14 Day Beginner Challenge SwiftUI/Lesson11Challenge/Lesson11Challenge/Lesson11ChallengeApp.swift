//
//  Lesson11ChallengeApp.swift
//  Lesson11Challenge
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

@main
struct Lesson11ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
