//
//  ContentView.swift
//  Lesson11Challenge
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

struct ContentView: View {
    //declared and initialized State property
    @State var num = 0
    
    var body: some View {
        VStack {
            
            Text(String(num)).foregroundColor(Color.black)
            
            //multiply button multiplies num by 2
            Button(action: {
                
                num *= 2
                
            }, label: {
                
                Text("Multiply")
            })
           
            //add button adds 2 to num
            Button(action: {
                
                num += 2
                
            }, label: {
                
                Text("Add")
            })
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
