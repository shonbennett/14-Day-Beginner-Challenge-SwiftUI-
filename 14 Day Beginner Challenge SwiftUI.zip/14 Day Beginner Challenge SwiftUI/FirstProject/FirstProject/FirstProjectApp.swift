//
//  FirstProjectApp.swift
//  FirstProject
//
//  Created by Shon Bennett on 1/10/22.
//

import SwiftUI

@main
struct FirstProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
