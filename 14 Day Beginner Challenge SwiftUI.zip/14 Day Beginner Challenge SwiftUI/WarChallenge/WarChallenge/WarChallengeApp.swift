//
//  WarChallengeApp.swift
//  WarChallenge
//
//  Created by Shon Bennett on 1/11/22.
//

import SwiftUI

@main
struct WarChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
