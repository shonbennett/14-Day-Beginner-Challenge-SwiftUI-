//
//  Lesson12ChallengeApp.swift
//  Lesson12Challenge
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

@main
struct Lesson12ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
