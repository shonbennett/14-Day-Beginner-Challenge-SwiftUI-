//
//  ContentView.swift
//  Lesson12Challenge
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

struct ContentView: View {
    //state variables
    @State private var num = 0
    @State private var continueDecreasing = false
    
    var body: some View {
        
        VStack {
            Text(String(num))
            Button(action: {
                if continueDecreasing == false{
                    increase()
                }
                else {
                    decrease()
                }
                
                // the number will continue decreasing until the number is less than zero. if we did the logic any other way, we would never be able to cycle from 0 to 50 successfully.
                if num > 50 {
                    continueDecreasing = true
                }
                else if num <= 0{
                    continueDecreasing = false
                }
               
            }, label: {
                HStack {
                    Image(systemName: "plus")
                    Text("Carry out an operation")
                }
            })
            
        }
    }
    
    func increase() {
        
        let randomNum = Int.random(in: 1...10)
        
        num += randomNum
    }
    
    func decrease() {
        
        let randomNum = Int.random(in: 1...10)
        
        num -= randomNum
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
