//
//  TestProjectApp.swift
//  TestProject
//
//  Created by Shon Bennett on 1/12/22.
//

import SwiftUI

@main
//the name of this structure is the name of the app, and it conforms to the App protocol
struct TestProjectApp: App {
    var body: some Scene {
        WindowGroup {
            //this is where the instance of the ContentView is created 
            ContentView()
        }
    }
}
