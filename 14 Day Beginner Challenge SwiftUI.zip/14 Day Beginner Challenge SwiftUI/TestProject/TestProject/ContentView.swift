//
//  ContentView.swift
//  TestProject
//
//  Created by Shon Bennett on 1/12/22.
//

import SwiftUI

//when you see a colon on structs, that means that this structure follows a protocol. in this case it is the View protocol
//protocol is the "building code"- a set of rules that specify the standards for constructed objects
//in formal Swift terms --- the ContentView conforms to the View protocol
//the code inside the structure must satisfy the View protocol. since it runs, we know ContentView satisfies it; so it has conformed!
//this represents the main view of this app
//an instance of this ContentView struct is created in the app file TestProjectApp
struct ContentView: View {
    //this is a computed property
    //it must return "some" instance that conforms to the View protocol
    var body: some View {
        // since this is one line, the return was omitted
        //this is an instance of the Text structure. we passed in input to this instance; we "initialized" it
        //this Text strucutre conformed to the View protocol since this ran
        //the dot notation was used to call the padding method on the Text instance
        Text("Hello, world!").padding()
    }
}

//this structure is not for the app. it is used to make the preview to the right
// this is a struct names ContentView_Previews and it conforms to the PreviewProvider
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().preferredColorScheme(.light)
    }
}
