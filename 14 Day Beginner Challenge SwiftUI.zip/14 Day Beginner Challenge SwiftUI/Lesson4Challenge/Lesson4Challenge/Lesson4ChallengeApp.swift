//
//  Lesson4ChallengeApp.swift
//  Lesson4Challenge
//
//  Created by Shon Bennett on 1/11/22.
//

import SwiftUI

@main
struct Lesson4ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
