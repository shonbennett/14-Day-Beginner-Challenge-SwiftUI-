//
//  ContentView.swift
//  Lesson4Challenge
//
//  Created by Shon Bennett on 1/11/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        VStack{ //Start main VStack (vertical)
            Spacer()
            ZStack{ //toronto zstack (overlap)
                
                Image("toronto")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                
                VStack { //text VStack
                    Text("CN Tower").background(Color.black).opacity(0.8)
                        .foregroundColor(Color.white)
                        .font(/*@START_MENU_TOKEN@*/.largeTitle/*@END_MENU_TOKEN@*/)
                        .cornerRadius(100)
                    
                    
                    Text("Toronto")
                        .foregroundColor(Color.white)
                        .background(Color.black)
                }
                
                
            }
            Spacer()
            
            ZStack{ //big ben zstack (overlap)
                Image("london").resizable()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    
                
                VStack {
                    
                    Text("Big Ben").background(Color.black)
                        .opacity(0.8)
                        .foregroundColor(Color.white)
                        .font(.largeTitle)
                    
                    Text("London")
                        .foregroundColor(Color.white)
                        .background(Color.black)
                    
                }
            }
            Spacer()
        } //end main VStack
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
