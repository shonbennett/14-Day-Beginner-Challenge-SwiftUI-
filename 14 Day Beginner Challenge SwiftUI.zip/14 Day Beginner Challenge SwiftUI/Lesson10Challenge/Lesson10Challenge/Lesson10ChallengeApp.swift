//
//  Lesson10ChallengeApp.swift
//  Lesson10Challenge
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

@main
struct Lesson10ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
