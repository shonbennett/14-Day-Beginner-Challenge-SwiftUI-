//
//  ContentView.swift
//  Lesson10Challenge
//
//  Created by Shon Bennett on 1/13/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            
            Button(action: {print("Shon, you just tapped the button.")}, label:{Text("Tap me")} )
            
            Button(action: {
                print("You just watched a video")}, label: {
                    HStack {
                    Image(systemName: "play.fill")
                    Text("Play video")
                }
                    
                })
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
